package cn.ac.iscas.cloudeploy.v2.util.application;

public class Constants {
	
}
