package cn.ac.iscas.cloudeploy.v2.model.entity.event;

public class NodeEvent {

}
